﻿using System;
/*using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;*/
using System.Windows;
/*using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;*/

namespace Калькулятор_2._0
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }

        bool topm = false;
        float a, b;
        float rez;

        bool plus = false;
        bool minus = false;
        bool umn = false;
        bool del = false;
        bool proz = true;
        bool tap = false;
        bool plTap = false;

        int cifra;

        private void pusher()
        {
            if (tap == true)
            {
                tap = false;
                Input.Content = "0";
            }
        }

        private void BtnTopMost_Click(object sender, RoutedEventArgs e)
        {
            if (topm == false)
            {
                Topmost = true;
                topm = true;
                tblkk.Text = "Открепить";
            }
            else
            {
                Topmost = false;
                topm = false;
                tblkk.Text = "Закрепить";
            }
        }

        private void Zero_Click(object sender, RoutedEventArgs e)
        {
            pusher();
            if (LbInput.Text != "0")
            {
                LbInput.Text += "0";
                //nuli();
            }
            else if (LbInput.Text == "ОШИБКА")
                LbInput.Text = "0";
        }

        private void Otr_Click(object sender, RoutedEventArgs e)
        {
            float t = float.Parse(LbInput.Text);
            t = t * -1;
            LbInput.Text = t.ToString();
        }

        private void Dec_Click(object sender, RoutedEventArgs e)
        {
            if (plTap == false)
            {
                string s = LbInput.Text;
                int colvo = s.Length;

                if (colvo >= 1)
                    LbInput.Text += ",";

                plTap = true;
            }
        }

        private void Ravno_Click(object sender, RoutedEventArgs e)
        {
            if (plus == true)
            {
                b = float.Parse(LbInput.Text);
                rez = a + b;
                LbPan.Text = a.ToString() + " + " + b.ToString() + " = ";
                LbInput.Text = rez.ToString();
                plus = false;
            }

            if (minus == true)
            {
                b = float.Parse(LbInput.Text);
                rez = a - b;
                LbPan.Text = a.ToString() + " - " + b.ToString() + " = ";
                LbInput.Text = rez.ToString();
                minus = false;
            }

            if (umn == true)
            {
                b = float.Parse(LbInput.Text);
                rez = a * b;
                LbPan.Text = a.ToString() + " * " + b.ToString() + " = ";
                LbInput.Text = rez.ToString();
                umn = false;
            }

            if (del == true)
            {
                b = float.Parse(LbInput.Text);
                if (b == 0)
                {
                    LbInput.Text = "ОШИБКА";
                    LbPan.Text = "";
                    a *= 0;
                }
                else
                {
                    rez = a / b;
                    LbPan.Text = a.ToString() + " / " + b.ToString() + " = ";
                    LbInput.Text = rez.ToString();
                }
                del = false;
            }
            //nuli();
            plTap = false;
        }

        private void One_Click(object sender, RoutedEventArgs e)
        {
            cifra = 1;
            ciferki();
        }

        void ciferki()
        {
            pusher();
            if (LbInput.Text == "0" || LbInput.Text == "ОШИБКА")
                LbInput.Text = cifra.ToString();
            else if (LbInput.Text != "0")
            {
                LbInput.Text += cifra.ToString();
                //nuli();
            }
        }

        private void Two_Click(object sender, RoutedEventArgs e)
        {
            cifra = 2;
            ciferki();
        }

        private void Three_Click(object sender, RoutedEventArgs e)
        {
            cifra = 3;
            ciferki();
        }

        private void Four_Click(object sender, RoutedEventArgs e)
        {
            cifra = 4;
            ciferki();
        }

        private void Five_Click(object sender, RoutedEventArgs e)
        {
            cifra = 5;
            ciferki();
        }

        private void Six_Click(object sender, RoutedEventArgs e)
        {
            cifra = 6;
            ciferki();
        }

        private void Seven_Click(object sender, RoutedEventArgs e)
        {
            cifra = 7;
            ciferki();
        }

        private void Eight_Click(object sender, RoutedEventArgs e)
        {
            cifra = 8;
            ciferki();
        }

        private void Nine_Click(object sender, RoutedEventArgs e)
        {
            cifra = 9;
            ciferki();
        }

        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            Ravno_Click(sender, e);
            a = float.Parse(LbInput.Text);
            LbPan.Text = a.ToString() + " +";
            ClearE_Click(sender, e);

            plus = true;
            minus = false;
            umn = false;
            del = false;
            proz = true;
        }

        private void Minus_Click(object sender, RoutedEventArgs e)
        {
            Ravno_Click(sender, e);
            a = float.Parse(LbInput.Text);
            LbPan.Text = a.ToString() + " -";
            ClearE_Click(sender, e);

            minus = true;
            plus = false;
            umn = false;
            del = false;
            proz = true;
        }

        private void Umnoj_Click(object sender, RoutedEventArgs e)
        {
            Ravno_Click(sender, e);
            a = float.Parse(LbInput.Text);
            LbPan.Text = a.ToString() + " x";
            ClearE_Click(sender, e);

            minus = false;
            plus = false;
            umn = true;
            del = false;
            proz = true;
        }

        private void Koren_Click(object sender, RoutedEventArgs e)
        {
            float fdr = float.Parse(LbInput.Text);
            LbPan.Text = "√" + fdr;
            double pow = Math.Pow(fdr, 0.5);
            LbInput.Text = pow.ToString();
        }

        private void Kvadrat_Click(object sender, RoutedEventArgs e)
        {
            float fdr = float.Parse(LbInput.Text);
            LbPan.Text = "" + fdr + "²";
            double pow = Math.Pow(fdr, 2);
            LbInput.Text = pow.ToString();
        }

        private void Drob_Click(object sender, RoutedEventArgs e)
        {
            float fdr = float.Parse(LbInput.Text);
            if (fdr != 0)
            {
                LbPan.Text = "1/(" + fdr + ")";
                fdr = 1 / (fdr);
                LbInput.Text = fdr.ToString();
            }
            else
                LbInput.Text = "ОШИБКА";
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            LbInput.Text = "0";
            LbPan.Text = "";
            a = 0;
            b = 0;
            rez = 0;
            plTap = false;
            plus = false;
            minus = false;
            umn = false;
            del = false;
            proz = true;
        }

        private void ClearE_Click(object sender, RoutedEventArgs e)
        {
            plTap = false;
            LbInput.Text = "0";
        }

        private void Delenie_Click(object sender, RoutedEventArgs e)
        {
            Ravno_Click(sender, e);
            a = float.Parse(LbInput.Text);
            LbPan.Text = a.ToString() + " /";
            ClearE_Click(sender, e);

            minus = false;
            plus = false;
            umn = false;
            del = true;
            proz = true;
        }

        private void Procent_Click(object sender, RoutedEventArgs e)
        {
            if (LbPan.Text == "")
                LbInput.Text = "0";
            else if (LbPan.Text != "" && proz == true)
            {
                string chislo = LbPan.Text;
                chislo = chislo.Remove(chislo.Length - 1);
                float perv = float.Parse(chislo);
                float vtor = float.Parse(LbInput.Text);
                float rezultat = (perv * vtor) / 100;
                LbInput.Text = rezultat.ToString();
                proz = false;
                //nuli();
            }
        }

        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            //0
            if (e.Key == System.Windows.Input.Key.NumPad0 || e.Key == System.Windows.Input.Key.D0)
                Zero_Click(sender, e);
            //1
            if (e.Key == System.Windows.Input.Key.NumPad1 || e.Key == System.Windows.Input.Key.D1)
                One_Click(sender, e);
            //2
            if (e.Key == System.Windows.Input.Key.NumPad2 || e.Key == System.Windows.Input.Key.D2)
                Two_Click(sender, e);
            //3
            if (e.Key == System.Windows.Input.Key.NumPad3 || e.Key == System.Windows.Input.Key.D3)
                Three_Click(sender, e);
            //4
            if (e.Key == System.Windows.Input.Key.NumPad4 || e.Key == System.Windows.Input.Key.D4)
                Four_Click(sender, e);
            //5
            if (e.Key == System.Windows.Input.Key.NumPad5 || e.Key == System.Windows.Input.Key.D5)
                Five_Click(sender, e);
            //6
            if (e.Key == System.Windows.Input.Key.NumPad6 || e.Key == System.Windows.Input.Key.D6)
                Six_Click(sender, e);
            //7
            if (e.Key == System.Windows.Input.Key.NumPad7 || e.Key == System.Windows.Input.Key.D7)
                Seven_Click(sender, e);
            //8
            if (e.Key == System.Windows.Input.Key.NumPad8 || e.Key == System.Windows.Input.Key.D8)
                Eight_Click(sender, e);
            //9
            if (e.Key == System.Windows.Input.Key.NumPad9 || e.Key == System.Windows.Input.Key.D9)
                Nine_Click(sender, e);
            //backspace
            if (e.Key == System.Windows.Input.Key.Back)
                Stir_Click(sender, e);
            //+
            if (e.Key == System.Windows.Input.Key.Add)
                Plus_Click(sender, e);
            //-
            if (e.Key == System.Windows.Input.Key.Subtract)
                Minus_Click(sender, e);
            //*
            if (e.Key == System.Windows.Input.Key.Multiply)
                Umnoj_Click(sender, e);
            //"/"
            if (e.Key == System.Windows.Input.Key.Divide)
                Delenie_Click(sender, e);
            //","
            if (e.Key == System.Windows.Input.Key.Decimal)
                Dec_Click(sender, e);
            //=
            if (e.Key == System.Windows.Input.Key.Enter)
                Ravno_Click(sender, e);
        }

        private void Stir_Click(object sender, RoutedEventArgs e)
        {
            string s = LbInput.Text;

            if (s.Length == 1)
                s = "0";
            else if (s.Length > 1)
                s = s.Remove(s.Length - 1);

            LbInput.Text = s;
            //nuli();
            plTap = false;
        }
    }
}
